fx_version 'cerulean'
game 'gta5'

shared_script 'config.lua'
client_script 'client/client.lua'
server_script 'server/server.lua'

ui_page "html/index.html"

files {
    'html/index.html',
    'html/style.css',
    'html/svg/*.svg',
    'html/svg/*.png'
}

escrow_ignore {
    'config.lua'
}

lua54 'yes'

dependency '/assetpacks'
dependency '/assetpacks'