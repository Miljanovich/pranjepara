Config = {}

function Notify(message)
    exports['nvNotification']:Show({sound = 'not1',icon = 'fas fa-exclamation-circle text-danger',title = 'Nastala chyba',message = message ,time = 7000,appname = 'Server'})
end
Config.Servername = ""

--Notifications
Config.Notification = "Du hast dein Schwarzgeld erfolgreich gewaschen!"
Config.Zuweniggeld = "Du hast zu wenig Geld!"
--Wenn man genau 0 hat oder im input 0 eingibt!
Config.amount0 = "Du hast gar kein Geld!"

Config.helpnotify = "Drücke ~INPUT_CONTEXT~ um dein Geld zu Waschen"

Config.Marker = 22

--Es werden Gebühren abgezogen
Config.gebuhren = true
--Von 100 Prozent wird behalten was in Config.gebruhrabgezogen ist Standard 90% und die restlichen 10% sind die Gebühren. Funktioniert nur wenn Config.gebuhren = true!!
Config.gebuhrabgezogen = 75 --Prozent

--Blip
Config.blipon = true
Config.Blip = {
	Blip = {
        Coord = vector3(1122.2540, -3194.4927, -40.3986),
        Name = "Moneywash",
        Sprite = 272,
        Scale = 1.0,
        Colour = 3,
    }
}

--Position
Config.PosX = 1122.2540
Config.PosY = -3194.4927
Config.PosZ = -40.3986
